import java.io.*;
import java.net.*;

/**
 * @author Chris Marshall.
 * client class with the main method where the program will enter first.
 */
public class Client {
    
        /**
         * main method where the program will start and create a new clientInstance object.
         * @param args string array for console input.
         * @throws Exception IOException method throws input/ output exception.
         */
	public static void main(String[] args) throws Exception {
		ClientInstance client = new ClientInstance();
		client.start();
	}
}

/**
 * @author Chris marshall
 * clientInstance class containing the methods to establish a connection to the server and to get the clients input/ send to the server.
 * contains portNumber, welcome, accepted, socket, in, out, isAllowedToChat, isServerConnected, clientName.
 * contains start(), establishConnection(), handleProfileSetUp(), handleOutgoingMessages(), getClientInput(), handleIncomingMessages(), closeConnection().
 */
class ClientInstance {
	
	/**
	* portNumber -private.
	* welcome -private.
	* accepted -private.
	* socket -private.
	* in -private.
	* out -private.
	* isAllowedToChat -private.
	* isServerConnected -private.
	* clientName -private.
	*/
	private int portNumber = 5555;
	private String welcome = "Please type your username.";
	private String accepted = "Your username is accepted.";
	private Socket socket = null;
	private BufferedReader in;
	private PrintWriter out;
	private boolean isAllowedToChat = false;
	private boolean isServerConnected = false;
	private String clientName;
	
        /**
         * start method which calls the relevant methods to establish and handle the messeges to and from the server.
         */
	public void start() {
		establishConnection();
		handleOutgoingMessages();
		handleIncomingMessages();
	}
	
        /**
         * method to establish the connection to the server.
         */
	private void establishConnection() {
			String serverAddress = getClientInput( "What is the address of the server that you wish to connect to?" );
			try {
				socket = new Socket( serverAddress, portNumber );
				in = new BufferedReader( new InputStreamReader( socket.getInputStream()));
				out = new PrintWriter(socket.getOutputStream(), true);
				isServerConnected = true;
			} 
			catch (IOException e) {
				System.err.println( "Exception in handleConnection(): " + e );
			}
			handleProfileSetUp();
		}
	/**
         * method to handle the clients profile. 
         * checks whether the client is allowed to chat and gets the client input.
         */	
	private void handleProfileSetUp() {
		String line = null;
		while ( ! isAllowedToChat ) {
			try { line = in.readLine(); }
			catch (IOException e) {
				System.err.println( "Exception in handleProfileSetUp:" + e );
			}
			if ( line.startsWith( welcome ) ) {
				out.println( getClientInput( welcome ) );
			} 
			else if (line.startsWith( accepted ) ) {
				isAllowedToChat = true;
				System.out.println( accepted +" You can type messages." );
				System.out.println( "To see a list of commands, type \\help." );
			}
			else System.out.println( line );
		}
	}

        /**
         * creates a thread to handle the out going messages.
         */
	private void handleOutgoingMessages() { 
		Thread senderThread = new Thread( new Runnable(){
			public void run() {
				while ( isServerConnected  ){
					out.println( getClientInput( null ) );
				}
			}
		});
		senderThread.start();
	}

        /**
         * method used to get the clients input and put that input into a buffered reader to be sent to the server in an input stream.
         * @param hint if the client has connected prints out welcome message else prints nothing.
         * @return message returns the message set for the client input.
         */
	private String getClientInput (String hint) {
		String message = null;
		try {
			BufferedReader reader = new BufferedReader(
				new InputStreamReader( System.in ) );
			if ( hint != null ) { System.out.println( hint ); }
			message = reader.readLine();
			if ( ! isAllowedToChat ) { clientName = message; }
		}
		catch (IOException e) {
			System.err.println( "Exception in getClientInput(): " + e );
		}
		return message;
	}

        /**
         * creates a thread then runs a nested method of run() to read the incoming messages from the thread.
         */
	private void handleIncomingMessages() { 
		Thread listenerThread = new Thread( new Runnable() {
			public void run() {
				while ( isServerConnected ) {
					String line = null;
					try {
						line = in.readLine();
						if ( line == null ) {
							isServerConnected = false;
							System.err.println( "Disconnected from the server" );
							closeConnection();
							break;
						}
						System.out.println( line );
					}
					catch (IOException e) {
						isServerConnected = false;
						System.err.println( "IOE in handleIncomingMessages()" );
						break;
					}
				}
			}
		});
		listenerThread.start();			
	}

        /**
         * method to close the connection to the server. 
         */
	void closeConnection() {
		try { 
			socket.close(); 
			System.exit(0); 
		} 
		catch (IOException e) {
			System.err.println( "Exception when closing the socket" );						
			System.err.println( e.getMessage() );
		}
	} 
		
}