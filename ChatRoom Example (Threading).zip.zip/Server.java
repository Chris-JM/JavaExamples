package server;

import java.io.*;
import java.net.*;
import java.util.*;

/**
* @author Christopher Marshall.
* Server class containing the main algorithms/ methods for the Server.
* Contains portNumber, welcome, accepted, commands, ss, clientNames, clientWriters, serverStart.
* Contains main(), start(), shutdown().
* contains nested class HandleSession.
*/
public class Server {
	/**
         * private global variable to be used in the server class.
         * portNumber -private.
         * welcome -private.
         * accepted -private.
         * commands -private.
         * ss -private.
         * clientNames -private.
         * clientWriters -private.
         * serverStart -private.
         */
	private int portNumber = 5555;
	private String welcome = "Please type your username.";
	private  String accepted = "Your username is accepted.";
	private String[] commands = { "\\help", "\\quit", "\\serverTime", "\\clientTime", "\\serverIP", "\\totalClients" };
	
	private ServerSocket ss; // for the method "shutDown"
	private HashSet<String> clientNames = new HashSet<String>();
	private HashSet<PrintWriter> clientWriters 
		= new HashSet<PrintWriter>(); // for many clients
        private long serverStart;
        
        /**
	* main method where the program enters first.
	* @param args string array.
	* Calls {@link Server#start()}
	* @throws IOException IOException IOException method throws input/ output exception.
	*/
	public static void main (String[] args) throws IOException {	
		Server server = new Server(); 
		server.start();
	}
	
        /**
         * method to start the server. 
         * this method also creates a thread for the HandleSession class. 
         * @throws IOException IOException method throws input/ output exception.
         */
	void start() throws IOException {	
                serverStart = System.currentTimeMillis();
		ss = new ServerSocket( portNumber );
		System.out.println( "Echo server at "
			+ InetAddress.getLocalHost()+ " is waiting for connections ..." );
		Socket socket;
		Thread thread;
		try {
			while ( true ) {
				socket = ss.accept();
				thread = new Thread( new HandleSession( socket ) );
				thread.start();
			}
		} 
		catch (Exception e)  {
			System.out.println( e.getMessage() );
		}
		finally {
			shutDown(); 
		}
	}
	
        /**
         * method to shut the server down.
         */
	public void shutDown() {
		try { 
			ss.close(); 
			System.out.println( "The server is shut down." );	
		} 
		catch (Exception e) {
			System.err.println( "Problem shutting down the server." );
			System.err.println( e.getMessage() );
		}
	}

        /**
         * HandleSession nested class which extend thread.
         * contains socket, name, in, out, clientStart.
         * contains HandleSession(), run(), createStreams(), getClientUserName(),listenForClientMesseges(), broadcast(), processClientRequest(), closeConnection().
         */
	class HandleSession extends Thread {
            
            /**
             * variables with global scope of HandleSession.
             * socket -private.
             * name -private.
             * in -private.
             * out -private.
             * clientStart -private.
             */
		private Socket socket; 
		String name;
		BufferedReader in = null;
		PrintWriter out = null;
                private long clientStart;
		
                /**
                 * constructor.
                 * @param socket passes the socket number from server.
                 */
		HandleSession (Socket socket) {
			this.socket = socket;
		}

                /**
                 * method to run the session, calls relevant methods to handle the session.
                 */
		public void run() {
			try {
				createStreams();
				getClientUserName();
				listenForClientMessages();
			} 
			catch (IOException e) {
				System.out.println( e );
			}
			finally {
				closeConnection();
			}
		}
               
                /**
                 * method to create the streams in which the clients will connect to,
                 * the streams will come in and be placed in a buffered reader and the out streams will be placed in a printwriter.
                 */
		private void createStreams() {
			try {
				in = new BufferedReader( new 	
					InputStreamReader( socket.getInputStream() ) );
				out = new PrintWriter( new 
					OutputStreamWriter( socket.getOutputStream() ) );
				clientWriters.add( out );
				System.out.println( "Client Connected. " );
                                clientStart = System.currentTimeMillis();
			} 
			catch (IOException e) {
				System.err.println( "Exception in createStreams(): " + e );
			}		
		} 

                /**
                 * method to get the client username, this method will check if the username desired by the client is already taken,
                 * if the username is already take it will inform the client this is the case and allow the client to enter another.
                 * once the client has entered a username the server and any additional clients are informed of the new client via the server window.
                 */
		private void getClientUserName() {
                    boolean userAccepted = false;
                    String currentClient = null;
			while ( true ) {
				out.println( welcome ); out.flush(); 
				try { currentClient = in.readLine(); } 
				catch (IOException e) {
					System.err.println("Exception in getClientUserName: " + e);
                                        break;
				}			
				if ( currentClient == null ) return; 
				if ( ! clientNames.contains( currentClient))  {
					clientNames.add( currentClient );
                                        userAccepted = true;
                                        name = currentClient;
					break;
				}
				out.println( "Sorry, this username is unavailable"); out.flush();
			}
                        if (userAccepted){
			out.println( accepted + "Please type messages." ); 
			out.flush(); 
			System.out.println( currentClient + " has entered the chat.");				
		}	
                }
		/**
                 * listens for the clients message.
                 * if the client enters a command (anything starting with \\) then the command is checked and the relevant method called.
                 * @throws IOException method throws input/ output exception.
                 */
		private void listenForClientMessages() throws IOException {
			String line; // input from a remote client
			while ( in != null ) {
				line = in.readLine();
				if ( line == null ) break;
				if ( line.startsWith("\\") ) {
					if ( !processClientRequest( line ) ) return;
				}
				else broadcast( name + " has said: " + line); 
			}
		}
		
                /**
                 * method to broadcast clients message to server.
                 * @param message clients message to be broadcast to server.
                 */
		private void broadcast (String message)
		{
			for (PrintWriter writer : clientWriters) {
				writer.println( message ); writer.flush();
			}
			System.out.println( message );
		}
		
                /**
                 * method to precess clients request, method will process the clients command. 
                 * @param command passes the string of the command the user selected.
                 * @return true.
                 */
		private boolean processClientRequest (String command) {
                    
                    if ( command.equals("\\help") ) {
			for (String c : commands) { 
                            out.println( "Command " + c ); out.flush(); 
			}
                    }    
                    if ( command.equals("\\quit") ) return false;
		    
                    if (command.equals("\\totalClients")) {
                        out.println("Number of clients on sever: " + clientNames.size());
                        out.flush();
                    }
                    if (command.equals("\\serverIP")){
                        InetAddress ip;
                        
                            try {
                                ip = InetAddress.getLocalHost();
                                out.println("Current IP address : " + ip.getHostAddress());
                                out.flush();
                            } catch (UnknownHostException ex) { System.out.println("Cant get server IP: " + ex);}
                        
                    }
                    if (command.equals("\\serverTime")){
                        out.println("server active for " + ((System.currentTimeMillis() - serverStart)/ 1000) + " seconds");
                        out.flush();
                    }
                    if (command.equals("\\clientTime")){
                        out.println("you have been on server for " + ((System.currentTimeMillis() - clientStart)/ 1000) + " seconds");
                        out.flush();
                    }
			return true;
		}
		
                /**
                 * method to close the clients connection to the server.
                 * lets the server know when a client leaves the server. 
                 */
		private void closeConnection() {
			if ( name != null ) {
				broadcast( name + " has left the chat." );
				clientNames.remove( name );
			}
			if ( out != null ) {
				clientWriters.remove( out );
			}
			try { 
				socket.close(); 
			} 
			catch (IOException e) {
				System.err.println( "Exception when closing the socket" );						
				System.err.println( e.getMessage() );
			}
		} 
		
	} 

}
