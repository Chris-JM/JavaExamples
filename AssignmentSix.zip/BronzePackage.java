import java.util.Scanner;

// bronze class, root class
public class BronzePackage{
	
	// global variables
	Scanner scan = new Scanner(System.in);
	
	protected double PhoneMinutes;
	protected double EveningAndWeekendMinutes;
	protected double BroadbandUsage;
	
	private String AccountType = "Bronze Account";
	private double PackageCost = 36.00;
	private double CostOfDaytimeCalls = 0.12;
	private double CostOfEveningAndWeekendCalls = 0.05;
	private double NoOfChannels = 60;
	private double BroadbandIncluded = 500;
	private double BroadBandExtraCost = 0.02;
	
	// empty constructor
	public BronzePackage(){
		
	}
	
	// constructor with parameters for user input. initialises main variables needed
	public BronzePackage(double phoneMinutes, double eveningAndWeekendMinutes, double broadbandUsage){
		
		PhoneMinutes = phoneMinutes;
		EveningAndWeekendMinutes = eveningAndWeekendMinutes;
		BroadbandUsage = broadbandUsage;
		
	}
	
	// method to get the phone minutes
	public double getPhoneMinutes(){
		return this.PhoneMinutes;
	}
	
	// method to set the phone minutes
	public void setPhoneMinutes(double phoneMinutes){
		while (phoneMinutes < 0){
			System.out.println("Invalid input. Enter valid daytime telephone minutes used: ");
			phoneMinutes = scan.nextInt();
		}
		
		PhoneMinutes = phoneMinutes; 
	}
	
	// method to get the evening and weekend minutes
	public double getEveningAndWeekendMinutes(){
		return EveningAndWeekendMinutes;
	}
	
	//method to set the evening and weekend minutes 
	public void setEveningAndWeekendMinutes(double eveningAndWeekendMinutes){
		while (eveningAndWeekendMinutes < 0){
			System.out.println("Invalid Input, Enter valid evening and weekend telephone minutes user: ");
			eveningAndWeekendMinutes = scan.nextInt();
		}
		EveningAndWeekendMinutes = eveningAndWeekendMinutes;
	}
	
	// method to get the broadband usage
	public double getBroadbandUsage(){
		return BroadbandUsage;
	}
	
	// method ot set the broadband usage
	public void setBroadbandUsage(double broadbandUsage){
		while (broadbandUsage < 0){
			System.out.println("Invalid Input. Enter valid total broadband usage (in Mb): ");
			broadbandUsage = scan.nextInt();
		}
		BroadbandUsage = broadbandUsage;
	}
	
	// calculates the daily call cost
	public double calcDaytimeCallCost(){
		return getPhoneMinutes() * CostOfDaytimeCalls;
	}
	
	// calculates evening and weekend calls cost
	public double calcEveningAndWeekendCallCost(){
		return EveningAndWeekendMinutes * CostOfEveningAndWeekendCalls;
	}
	
	// calculates broadband cost, checks if usage is over limit then subtracts usage from limit to times by cost
	public double calcBroadbandCost(){
		
		double broadbandOver = 0;
		
		if (getBroadbandUsage() > BroadbandIncluded){
			broadbandOver = BroadbandUsage - BroadbandIncluded;
		}
		
		return broadbandOver * BroadBandExtraCost;
	}
	
	// calculates total cost
	public double calcTotalCost(){
		return PackageCost + calcDaytimeCallCost() + calcEveningAndWeekendCallCost() + calcBroadbandCost();
	}
	
	// prints out results
	public void printPackage(){
		
		System.out.println("Account summary for " + AccountType);
		System.out.println("Package Cost: " + PackageCost);
		System.out.println("Cost of daytime calls: " + CostOfDaytimeCalls + "/min");
		System.out.println("Cost of evening and weekend calls: " + CostOfEveningAndWeekendCalls + "/min");
		System.out.println("Number of channels: " + NoOfChannels);
		System.out.println("Broadband Included: " + BroadbandIncluded + "Mb");
		System.out.println("Total daytime calls cost: " + calcDaytimeCallCost());
		System.out.println("Total evening calls cost: " + calcEveningAndWeekendCallCost());
		System.out.println("Total (extra) broadband cost: " + calcBroadbandCost());
		System.out.println("Total cost: " + calcTotalCost());
		System.out.println();
		
	}

}