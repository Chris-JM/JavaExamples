// silver class extends bronze class
public class SilverPackage extends BronzePackage{
	
	// global variables
	protected double PhoneMinutes;
	protected double EveningAndWeekendMinutes;
	protected double BroadbandUsage;
	
	private String AccountType = "Silver Account";
	private double PackageCost = 46.00;
	private double CostOfDaytimeCalls = 0.12;
	private double CostOfEveningAndWeekendCalls = 0;
	private double NoOfChannels = 130;
	private double BroadbandIncluded = 1000;
	private double BroadBandExtraCost = 0.01;
	
	// empty constructor
	public SilverPackage(){
		
	}
	
	// constructor with parameters for user input. initialises main variables needed
	public SilverPackage(double phoneMinutes, double eveningAndWeekendMinutes, double broadbandUsage){
		
		super(phoneMinutes, eveningAndWeekendMinutes, broadbandUsage);
		
		PhoneMinutes = phoneMinutes;
		EveningAndWeekendMinutes = eveningAndWeekendMinutes;
		BroadbandUsage = broadbandUsage;
		
	}
	
	// calculates broadband cost
	public double calcBroadbandCost(){
		
		double broadbandOver = 0;
		
		if (getBroadbandUsage() > BroadbandIncluded){
			broadbandOver = BroadbandUsage - BroadbandIncluded;
		}
		
		return broadbandOver * BroadBandExtraCost;
	}
	
	// calculates total cost
	public double calcTotalCost(){
		return PackageCost + calcDaytimeCallCost() + calcBroadbandCost();
	}
	
	// prints our information
	public void printPackage(){
		
		System.out.println("Account summary for " + AccountType);
		System.out.println("Package Cost: " + PackageCost);
		System.out.println("Cost of daytime calls: " + CostOfDaytimeCalls + "/min");
		System.out.println("Cost of evening and weekend calls: " + CostOfEveningAndWeekendCalls + "/min");
		System.out.println("Number of channels: " + NoOfChannels);
		System.out.println("Broadband Included: " + BroadbandIncluded + "Mb");
		System.out.println("Total daytime calls cost: " + calcDaytimeCallCost());
		System.out.println("Total evening calls cost: " + CostOfEveningAndWeekendCalls);
		System.out.println("Total (extra) broadband cost: " + calcBroadbandCost());
		System.out.println("Total cost: " + calcTotalCost());
		System.out.println("Spotify Account provided");
		System.out.println();
		
	}
	
}