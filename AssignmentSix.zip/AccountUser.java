import java.util.Scanner;

// main class
public class AccountUser{
	
	// main method
	public static void main(String [] args){
		
		// creating a new scanner 
		Scanner scan = new Scanner(System.in);
		
		// creating an instance of bronze
		BronzePackage bronze = new BronzePackage();
		
		// print out to user and take input 
		System.out.println("Input daytime telephone minutes used: ");
		bronze.setPhoneMinutes(scan.nextInt());
		
		System.out.println("Input evening and weekend telephone minutes user: ");
		bronze.setEveningAndWeekendMinutes(scan.nextInt());
		
		System.out.println("Input the total broadband usage (in Mb): ");
		bronze.setBroadbandUsage(scan.nextInt());
		
		// initialise variables by getting them from bronze class
		double phoneMinutes = bronze.getPhoneMinutes();
		double eveningAndWeekendMinutes = bronze.getEveningAndWeekendMinutes();
		double broadbandUsage = bronze.getBroadbandUsage();
		
		// create an instance of silver and bronze passing the input from the user
		SilverPackage silver = new SilverPackage(phoneMinutes, eveningAndWeekendMinutes, broadbandUsage);
		GoldPackage gold = new GoldPackage(phoneMinutes, eveningAndWeekendMinutes, broadbandUsage);
		
		// calls the methods to print
		bronze.printPackage();
		silver.printPackage();
		gold.printPackage();
		
		// assign the total cost of each package to a variable
		double bronzeTotalCost = bronze.calcTotalCost();
		double silverTotalCost = silver.calcTotalCost();
		double goldTotalCost = gold.calcTotalCost();
		
		// calculate cheapest package
		if (bronzeTotalCost < silverTotalCost && bronzeTotalCost < goldTotalCost){
			System.out.println("Bronze Account is the cheapest.");
		}else if (silverTotalCost < bronzeTotalCost && silverTotalCost < goldTotalCost){
			System.out.println("Silver Account is the cheapest.");
		}else if (goldTotalCost < bronzeTotalCost && goldTotalCost < silverTotalCost){
			System.out.println("Gold Account is the cheapest.");
		}
		
	}
	
}