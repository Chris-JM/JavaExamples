import java.util.Scanner;

// main class
public class Game{
	
	// mian method
	public static void main(String[] args){
		
		// scanner
		Scanner scan = new Scanner(System.in);
		
		// takes user input and loops until the correct value is entered 
		System.out.println("Please enter number of rounds: ");
		int rounds = scan.nextInt();
		while(rounds < 0){
			System.out.println("Invalid input. Enter valid number of rounds: ");
			rounds = scan.nextInt();
		}
		// creates a new ThreeDiceScorer array, using the rounds as the array size 
		ThreeDiceScorer[] scorer = new ThreeDiceScorer[rounds + rounds];
		
		// algorithm to obtain the 3 dice roles and create a new element in the array with these rolls, repeats until array is full
		for (int i = 0; i < scorer.length; i++){
				int diceValue1 = 1 + (int)(6 * Math.random());
				int diceValue2 = 1 + (int)(6 * Math.random());
				int diceValue3 = 1 + (int)(6 * Math.random());
				
				scorer[i] = new ThreeDiceScorer(diceValue1, diceValue2, diceValue3);
		}
		
		// variables needed for output/ calculations
		int player1Wins = 0;
		int player1Points = 0;
		int player2Wins = 0;
		int player2Points = 0;
		double player1PointsAverage;
		double player2PointsAverage;
		
		//for loop to print out the results of each round and calculte the score and determine the winner
		for (int i = 0; i < rounds; i++){
			
			System.out.println("Round: " + (i+1));
			System.out.println("Player 1; " + scorer[i].getDie1() + " " + scorer[i].getDie2() + " " + scorer[i].getDie3());
			System.out.println("Points: " + scorer[i].getScore());
			System.out.println("Player 2; " + scorer[i + rounds].getDie1() + " " + scorer[i + rounds].getDie2() + " " + scorer[i + rounds].getDie3());
			System.out.println("Points: " + scorer[i + rounds].getScore());
			
			if(scorer[i].getScore() > scorer[i + rounds].getScore()){
				System.out.println("Round Winner is Player 1");
				player1Wins++;
				player1Points += scorer[i].getScore();
			}else if (scorer[i].getScore() < scorer[i + rounds].getScore()){
				System.out.println("Round Winner is Player 2");
				player2Wins++;
				player2Points += scorer[i + rounds].getScore();
			}else {
				System.out.println("Round is a draw, nobody wins");
				player1Points += scorer[i].getScore();
				player2Points += scorer[i + rounds].getScore();
			}
			System.out.println();
		}
		
		// calculates the avarge score for each player
		if (rounds != 0){
		player1PointsAverage = player1Points/rounds;
		player2PointsAverage = player2Points/rounds;
		}else{
			player1PointsAverage = 0;
			player2PointsAverage = 0;
		}
		
		// prints out the results of the game
		System.out.println("Total wins: ");
		System.out.println("Player 1: " + player1Wins);
		System.out.println("Player 2: " + player2Wins);
		System.out.println("Total points: ");
		System.out.println("Player 1: " + player1Points);
		System.out.println("Player 2: " + player2Points);
		System.out.println("Average points per round: ");
		System.out.println("Player 1: " + player1PointsAverage);
		System.out.println("Player 2: " + player2PointsAverage);
		
		// works out the overall winner
		if(player1Points > player2Points){
				System.out.println("Overall points winner is Player 1");
			}else if (player1Points < player2Points){
				System.out.println("Overall points winner is Player 2");
			}else 
				System.out.println("Overall points winner is a draw, nobody wins");
	
	}
}