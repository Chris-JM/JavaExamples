// Three dice scorere class which extends the threeDice class
public class ThreeDiceScorer extends ThreeDice{
		
	// class constructor, calls super class passing the values for s1, s2, s3
	public ThreeDiceScorer(int s1, int s2, int s3){
		super(s1, s2, s3);
	}
	
	// method to get the score for each combination/ situation of the dice rolls 
	public int getScore(){
		
		int score;
		
		if (threeSame() == true)
			score = getDie1() + getDie2() + getDie3() + 60;
		else if (runOfThree() == true) 
			score = getDie1() + getDie2() + getDie3() + 40;
		else if (pair() == true) 
			score = getDie1() + getDie2() + getDie3() + 20;
		else 
			score = getDie1() + getDie2() + getDie3();
		
		return score;
			
	}
	
	
}